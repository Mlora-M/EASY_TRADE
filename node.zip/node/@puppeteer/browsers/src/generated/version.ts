/**
 * @internal
 */
export const packageVersion = '2.10.5';
