/**
 * @internal
 */
export declare const packageVersion = "2.10.5";
//# sourceMappingURL=version.d.ts.map