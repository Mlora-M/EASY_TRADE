# Installation
> `npm install --save @types/yauzl`

# Summary
This package contains type definitions for yauzl (https://github.com/thejoshwolfe/yauzl).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/yauzl.

### Additional Details
 * Last updated: Tue, 07 Nov 2023 15:11:36 GMT
 * Dependencies: [@types/node](https://npmjs.com/package/@types/node)

# Credits
These definitions were written by [Florian Keller](https://github.com/ffflorian).
