<div align="center">
  <img width="200" height="200"
    src="https://s3.amazonaws.com/pix.iemoji.com/images/emoji/apple/ios-11/256/crayon.png">
  <h1>@jimp/plugin-mask</h1>
  <p>mask an image with another image.</p>
</div>

Masks a source image on to this image using average pixel colour. A completely black pixel on the mask will turn a pixel in the image completely transparent.

- [mask](http://jimp-dev.github.io/jimp/api/jimp/classes/jimp#mask)
