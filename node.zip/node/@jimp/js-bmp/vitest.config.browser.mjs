import config from "@jimp/config-vitest/browser";

export default config;
