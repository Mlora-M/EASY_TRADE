<div align="center">
  <img width="200" height="200"
    src="https://s3.amazonaws.com/pix.iemoji.com/images/emoji/apple/ios-11/256/crayon.png">
  <h1>@jimp/plugin-flip</h1>
  <p>flip an image.</p>
</div>

Flip the image horizontally or vertically. Defaults to horizontal.

Also aliased as `mirror`

- [flip](http://jimp-dev.github.io/jimp/api/jimp/classes/jimp#flip)
- [mirror](http://jimp-dev.github.io/jimp/api/jimp/classes/jimp#mirror)
