declare module "parse-bmfont-ascii" {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  export default function parseASCII(data: string): any;
}
