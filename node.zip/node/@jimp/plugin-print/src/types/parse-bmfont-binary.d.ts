declare module "parse-bmfont-binary" {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  export default function readBinary(data: Buffer): any;
}
