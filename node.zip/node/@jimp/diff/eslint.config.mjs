import shared from "@jimp/config-eslint/base.js";
export default [...shared];